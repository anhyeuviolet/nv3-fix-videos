<?php

/**
 * @Project VIDEO CLIPS AJAX 3.x
 * @Author PHAN TAN DUNG (phantandung92@gmail.com)
 * @Copyright (C) 2013 PHAN TAN DUNG. All rights reserved
 * @Createdate Dec 08, 2013, 09:57:59 PM
 */

if( ! defined( 'NV_IS_MOD_VIDEOCLIPS' ) ) die( 'Stop!!!' );

global $array_op, $module_name, $module_data, $nv_Request, $VideoData, $db, $lang_module, $user_info, $client_info, $topicList, $module_info, $module_file, $configMods, $my_head, $isDetail;

// Neu chua co video nao
if( empty( $VideoData ) ) return "";

$topic = $topicList[$VideoData['tid']];

$comments = array();
$cpgnum = 0;
$commNext = false;
if( $VideoData['comm'] )
{
	if( $nv_Request->isset_request( 'cpgnum', 'post' ) ) $cpgnum = $nv_Request->get_int( 'cpgnum', 'post', 0 );

	$sql = "SELECT a.*, b.username, b.email, b.full_name, b.gender, b.photo, b.view_mail, b.md5username 
    FROM `" . NV_PREFIXLANG . "_" . $module_data . "_comm` a, `" . NV_USERS_GLOBALTABLE . "` b 
    WHERE a.cid=" . $VideoData['id'] . " AND a.status=1 AND a.userid=b.userid 
    ORDER BY a.id DESC LIMIT " . $cpgnum . ", " . ( $configMods['commNum'] + 1 );
	$result = $db->sql_query( $sql );
	$i = 0;
	while ( $row = $db->sql_fetch_assoc( $result ) )
	{
		if( $i <= $configMods['commNum'] - 1 )
		{
			$comments[$i] = $row;
			$comments[$i]['full_name'] = ! empty( $row['full_name'] ) ? $row['full_name'] : $row['username'];
			$comments[$i]['userView'] = NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=users&amp;" . NV_OP_VARIABLE . "=memberlist/" . change_alias( $row['username'] ) . "-" . $row['md5username'];
			$comments[$i]['email'] = $row['view_mail'] ? $row['email'] : "";
			$comments[$i]['photo'] = NV_BASE_SITEURL . ( ! empty( $row['photo'] ) ? $row['photo'] : "themes/default/images/users/no_avatar.jpg" );
			$comments[$i]['posttime'] = nv_ucfirst( nv_strtolower( nv_date( "l, j F Y, H:i", $row['posttime'] ) ) );
		}
		else
		{
			$commNext = true;
			break;
		}
		++$cpgnum;
		++$i;
	}
}

$xtpl = new XTemplate( "detail.tpl", NV_ROOTDIR . "/themes/" . $module_info['template'] . "/modules/" . $module_file );
$xtpl->assign( 'LANG', $lang_module );
$xtpl->assign( 'NV_BASE_SITEURL', NV_BASE_SITEURL );
$xtpl->assign( 'MODULECONFIG', $configMods );
$xtpl->assign( 'MODULEURL', nv_url_rewrite( NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&" . NV_NAME_VARIABLE . "=" . $module_name . "&" . NV_OP_VARIABLE . "=" . $VideoData['alias'], 1 ) );

// if( $nv_Request->isset_request( 'cpgnum', 'post' ) )
// {
	// echo listComm();
	// exit;
// }

// if( $nv_Request->isset_request( 'commentReload', 'post' ) )
// {
	// echo commentReload();
	// exit;
// }

$xtpl->assign( 'DETAILCONTENT', $VideoData );
if( defined( 'NV_IS_MODADMIN' ) ) $xtpl->parse( 'main.isAdmin' );
// if( $VideoData['comm'] ) $xtpl->parse( 'main.ifComm' );
if( ! empty( $VideoData['bodytext'] ) ) $xtpl->parse( 'main.bodytext' );

// if( $VideoData['comm'] )
// {
	// $xtpl->assign( 'COMMENTSECTOR', commentReload() );
	// $xtpl->parse( 'main.commentSector' );
// }

if( $isDetail )
{
	$xtpl->parse( 'main.scrollPlayer' );
}

$xtpl->parse( 'main' );
$content = $xtpl->text( "main" );

if( $nv_Request->isset_request( 'aj', 'post' ) and ( $aj = filter_text_input( 'aj', 'post', '', 0 ) == 1 ) )
{
	echo $content;
	exit;
}

$content = "<div id=\"videoDetail\">" . $content . "</div>\n";

$my_head .= "<script type=\"text/javascript\" src=\"" . NV_BASE_SITEURL . "modules/" . $module_file . "/js/jwplayer7/jwplayer.js\"></script>\n";
?>