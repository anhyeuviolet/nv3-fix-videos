<?php

/**
 * @Project NUKEVIET 3.0
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2010 VINADES.,JSC. All rights reserved
 * @Createdate 7-17-2010 14:43
 */

if (!defined('NV_SYSTEM'))
{
    die('Stop!!!');
}

define('NV_IS_MOD_ALBUMS', true);
require_once NV_ROOTDIR . "/modules/" . $module_name . '/videodb.php';

$adb = new albumdb();
$array_album = array();
$result = $adb->getAllActiveAlbumOBW();
$catalias = isset($array_op[0]) ? trim($array_op[0]) : "";

//albumid
$aID = $vID = 0;
while ($rs = $db->sql_fetchrow($result))
{
    $array_album[] = $rs;
    if ($catalias == $rs['alias'])
    {
        $aID = $rs['albumid'];
    }
}
//end albumid

//get id video
if ($aID > 0 and isset($array_op[2]))
{
    $vID = $array_op[2];
}
//end get id video

//Menu
foreach ($array_album as $rs)
{
    $act = ($rs['albumid'] == $aID and $aID > 0) ? 1 : 0;
    $url_link = NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $module_name . '&amp;' . NV_OP_VARIABLE . "=" . $rs['alias'];
    $nv_vertical_menu[] = array($rs['name'], $url_link, $act, 'submenu' => array());
}

//End Menu
?>