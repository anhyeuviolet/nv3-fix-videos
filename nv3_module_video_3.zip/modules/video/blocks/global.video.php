<?php

/**
 * @Author Truong Xuan Luc(xuanluchp@gmail.com)
 * @Copyright freeware
 * @Createdate 30/07/2011 18:00
 */
if ( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

if ( ! function_exists( 'nv_video' ) )
{
	function video ( )
    {
		global $global_config, $module_name, $module_data, $module_file, $global_array_cat, $module_config, $module_info, $db, $my_head;
		$xtpl = new XTemplate( "global.block_video.tpl", NV_ROOTDIR . "/themes/" . $module_info['template'] . "/modules/video" );
		$sql = "SELECT * FROM `" . NV_PREFIXLANG . "_video_picture` ORDER BY `pictureid` DESC limit 0, 1";
		$result = $db->sql_query ( $sql );
		list( $pictureid, $name, $alias, $path, $description, $numview, $thumb_name, $albumid, $weight, $num_view, $vpath ) =  $db->sql_fetchrow ( $result );
		$title = nv_clean60 ( strip_tags ( $name ), 50 );
		if (!empty($path))
		{
			$array_img = explode("|", $path);
		}
		else
		{
			$array_img = array("", "");
		}

		if ( ! empty( $array_img ) and file_exists( NV_UPLOADS_REAL_DIR . "/video/" . $path ) )
		{
			$url_img = NV_BASE_SITEURL . NV_UPLOADS_DIR . "/video/"  . $path;
			$thumb_name = NV_BASE_SITEURL . NV_UPLOADS_DIR . "/video/"  . $thumb_name;
		}
		else
		{
			$url_img = $path;
		}
		if ( ! empty( $vpath ) and file_exists( NV_UPLOADS_REAL_DIR . "/video/" . $vpath ) )
		{
			$url_v = NV_BASE_SITEURL . NV_UPLOADS_DIR . "/video/" . $vpath;
		}
		else
		{
			$url_v = $vpath;
		}
		$mang = array('tieude'=> $title, 'thumb'=> $url_img, 'urlvideo'=>$description, 'duongdan'=>	$url_v );
		$xtpl->assign('DATA',$mang);
		$sql1 = "SELECT * FROM `" . NV_PREFIXLANG . "_video_picture` ORDER BY `num_view` DESC LIMIT 1, 4";
		$result1 = $db->sql_query ( $sql1 );
		while ($data= $db->sql_fetchrow ( $result1 )  )
		{
			//$catid = explode( ',', $data ['albumid'] );
			//$xtpl->assign( 'URL_V', NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=video&amp;" . NV_OP_VARIABLE . "=" . $data[$catid]['alias'] . "/" . $data['alias'] . "/" . $data['pictureid'] . "" );
			//$link1= NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=video&amp;" . NV_OP_VARIABLE . "=" . $catalias . "/" . $data['alias'] . "/" . $data['pictureid'] . "" );
			$data['path'] = NV_BASE_SITEURL . NV_UPLOADS_DIR . "/video". $data['path'];
			$data['name'] = nv_clean60 ( strip_tags ( $data['name'] ), 50 );
			$row = array('title'=> $data['name'], 'thumb'=> $data['path']);
			$xtpl->assign('LIST',$row);
			$xtpl->parse('main.loop');
		}
		$xtpl->parse('main');
		return $xtpl->text( 'main' );
	}
	$content = video( );
}
?>