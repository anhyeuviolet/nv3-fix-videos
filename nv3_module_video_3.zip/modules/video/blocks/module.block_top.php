<?php
global $module_data;
$content  ="<div id=\"blockmusicalbum\">";
$source = mysql_query("SELECT * FROM " . NV_PREFIXLANG . "_" . $module_data . " ORDER BY num_view DESC LIMIT 0,10");
while ($data = mysql_fetch_array($source) ){
$content .=  "<img src=\"".$data['thumb']."\" />";
$content .="<p><a href=\"".NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;nv=videonline&amp;theloai=".$data['theloai']."&amp;album=".$data['id']."\">".$data['title']."</a></p>";
$content .="<p>Đã đăng : ".$data['who_post']."</p>";
}
$content  .=  "</div>";
?>