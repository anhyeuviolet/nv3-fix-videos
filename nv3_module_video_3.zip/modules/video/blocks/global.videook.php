<?php

/**
 * @Author Truong Xuan Luc(xuanluchp@gmail.com)
 * @Copyright freeware
 * @Createdate 30/07/2011 18:00
 */
if ( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

if ( ! function_exists( 'nv_videonline' ) )
{
	function videonline ( )
    {
		global $global_config, $module_name, $module_data, $module_file, $global_array_cat, $module_config, $module_info, $db, $my_head;
		$my_head .= "<script type=\"text/javascript\" src=\"" . NV_BASE_SITEURL . "themes/default/js/sagscroller_tinvan.js\"></script>";
		$my_head .= "<link rel=\"stylesheet\" href=\"" . NV_BASE_SITEURL . "themes/default/css/tinvan.css\" />\n";
		$my_head .= "<style type=\"text/css\">
		.block_video{
			padding:1px;
			line-height:16px;
			text-align:center;
		}
		.block_video .img123{
			float:left;
			margin-right:5px;
			width:80px;
			padding:2px;
			border:1px solid #F3F3F3;
		}
		</style>";
		$xtpl = new XTemplate( "global.block_videonline.tpl", NV_ROOTDIR . "/themes/" . $module_info['template'] . "/modules/videonline" );
		$sql = "SELECT id, title, thumb, theloai, duongdan, who_post, list, body, num_view FROM `" . NV_PREFIXLANG . "_videonline` ORDER BY `num_view` ASC limit 0, 6";
		$result = $db->sql_query ( $sql );

		list( $id, $title, $thumb, $theloai, $duongdan, $who_post, $list, $body, $num_view ) =  $db->sql_fetchrow ( $result );
		$title = nv_clean60 ( strip_tags ( $title ), 50 );
		if (!empty($thumb))
		{
			$array_img = explode("|", $thumb);
		}
		else
		{
			$array_img = array("", "");
		}

		if ( ! empty( $array_img ) and file_exists( NV_UPLOADS_REAL_DIR . "/videonline/" . $thumb ) )
		{
			$url_img = NV_BASE_SITEURL . NV_UPLOADS_DIR . "/videonline/"  . $thumb;
			$thumb_name = NV_BASE_SITEURL . NV_UPLOADS_DIR . "/videonline/"  . $thumb_name;
		}
		else
		{
			$url_img = $thumb;
		}
		if ( ! empty( $duongdan ) and file_exists( NV_UPLOADS_REAL_DIR . "/videonline/" . $duongdan ) )
		{
			$url_v = NV_BASE_SITEURL . NV_UPLOADS_DIR . "/videonline/" . $duongdan;
		}
		else
		{
			$url_v = $duongdan;
		}
		$mang = array('tieude'=> $title, 'thumb'=> $url_img, 'urlvideo'=>$theloai, 'duongdan'=>	$url_v, );
		$xtpl->assign('DATA',$mang);
			
		/*$sql1 = "SELECT id, title, thumb, theloai, duongdan, who_post, list, body, num_view FROM `" . NV_PREFIXLANG . "_videonline` ORDER BY `num_view` ASC limit 0, 6";
		$result = $db->sql_query ( $sql1 );
		while( list ( $id, $title, $thumb, $theloai, $duongdan, $who_post, $list, $body, $num_view ) =  $db->sql_fetchrow ( $result ));
		{
			$title = nv_clean60 ( strip_tags ( $title ), 50 );
			$listvideo = array('tieude'=> $title, 'thumb'=> $thumb, 'urlvideo'=>$theloai,'duongdan'=> $duongdan );
			$xtpl->assign('LIST',$listvideo);
			
		}*/
		$xtpl->parse('main.loop');
		$xtpl->parse('main');
		return $xtpl->text( 'main' );
	}
	$content = videonline( );
}
?>