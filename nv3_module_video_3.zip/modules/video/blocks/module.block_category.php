<?php
global $module_data;
$content  ="<div id=\"blockmusiccategogy\">";
$sqla = "SELECT id, num,  title FROM `" . NV_PREFIXLANG . "_" . $module_data . "_category` ORDER BY num";
$resuilta = $db->sql_query( $sqla );
while ( $rowa = $db->sql_fetchrow( $resuilta ) )
{
	$content .=  "<p><a href=\"".NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;nv=videonline&amp;theloai=".$rowa['num']."\" class=\"musiclink\">".$rowa['title']."</a></p>";
}
$content  .=  "</div>";
?>