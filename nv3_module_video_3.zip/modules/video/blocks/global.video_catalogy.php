<?php
/**
	* @Project NUKEVIET 3.0.11
	* @Author dangdinhtu(dlinhvan@gmail.com)
	* @Edite: Trương Xuân Lực (xuanluchp@gmail.com)
	* @copyright 2011
	* @createdate 05/6/2011 8h00.PM"
*/

if ( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

$limit = 6; # so tin can hien thi
$hometitle= 50; # Độ dài của tiêu đề

global $global_config, $db, $lang_global, $site_mods, $module_file;
//$sql = "SELECT topic_id, forum_id, icon_id, topic_attachment, topic_approved, topic_reported, topic_title, topic_poster, topic_time, topic_time_limit, topic_views, topic_replies, topic_replies_real, topic_status, topic_type, topic_first_post_id, topic_first_poster_name, topic_first_poster_colour, topic_last_post_id, topic_last_poster_id, topic_last_poster_name, topic_last_poster_colour, topic_last_post_subject,topic_last_post_time FROM phpbb_topics ORDER BY topic_last_post_time DESC LIMIT 0,  " . $limit. "";
$sql = "SELECT * FROM `nv3_vi_video_picture` ORDER BY `pictureid`  DESC LIMIT 0 , 4";

    $result = $db->sql_query ( $sql );
       
        while ( list ( $pictureid, $name, $alias, $path, $description, $numview, $thumb_name, $albumid, $weight, $num_view, $vpath ) = $db->sql_fetchrow ( $result ) )
        
		{// can chu y duong dan forum/viewtopic.php?f='.$forum_id.'&t='.$topic_id.
			$topic_title = strip_tags ( $topic_title );
			$topic_title = nv_clean60 ( $topic_title, $hometitle );
			$topic_last_post_time = date ('h:i - d/m/Y', $topic_last_post_time );
			$content .= '
                        <div style="border-bottom: 1px dotted  #aaf0ee; padding: 6px 0px;">
                        <a href="' . NV_BASE_SITEURL . 'phpbb/viewtopic.php?f='.$forum_id.'&amp;t='.$topic_id.'#p'. $topic_last_post_id .'" title="'.$topic_title.' "><img src="'. NV_BASE_SITEURL .'themes/default/images/arrow_next.gif" alt="list" />&nbsp;&nbsp;<span style="color:#fa8f04; font-weight: bold;">'. $name .':</span><br />'.$topic_title.'<br /></a><p style="font-size:11px;"> Đăng: <span style="color:#5b5b5b; font-style: italic; font-size: 10px;">'. $topic_last_post_time .' - Xem: '. $topic_views .' lượt.</span></p>
                        </div>
            ';
           
        }

?>