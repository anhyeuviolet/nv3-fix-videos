<?php

if ( ! defined( 'NV_SYSTEM' ) ) die( 'Stop!!!' ); 

$content = '';
$content.="
	<object classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" width=\"240\" height=\"350\" id=\"single1\" name=\"single1\">
	<param name=\"movie\" value=\"".NV_BASE_SITEURL."JW/player.swf\">
	<param name=\"allowfullscreen\" value=\"true\">
	<param name=\"allowscriptaccess\" value=\"always\">
	<param name=\"wmode\" value=\"transparent\">
	<param name=\"flashvars\" value=\"file=".NV_BASE_SITEURL."list_video.php&backcolor=bbccff&frontcolor=cccccc&lightcolor=66cc00&playlist.size=135&skin=".NV_BASE_SITEURL ."JW/beelden_.zip&playlist=bottom\">
	<embed width=\"240\" height=\"450\" 
		type=\"application/x-shockwave-flash\" 
		src=\"".NV_BASE_SITEURL."JW/player.swf\" 
		flashvars=\"logo=nguyen_02.jpg&image=nguyen_02.jpg&skin=".NV_BASE_SITEURL ."JW/beelden_.zip&file=".NV_BASE_SITEURL."list_video.php&stretching=exactfit&screencolor=bbddss&playlist=bottom&playlistsize=220\" allowfullscreen=\"true\">
	</embed>
	</object>
";		
?>