<?php

/**
* @Project nukeviet 3.0 rc12 
* @Author dangdinhtu (dlinhvan@gmail.com)   
* @Copyright (C) 2010 All rights reserved
* @Createdate 18/10/2010 23:10
*/

if ( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

if ( ! function_exists( 'nv_nv_videos' ) )
{
	function nv_videos ( )
    {
		global $global_config, $module_name, $module_data, $module_file, $global_array_cat, $module_config, $module_info, $db, $my_head, $op;
		$my_head .= "<link rel=\"Stylesheet\" href=\"" . NV_BASE_SITEURL . "js/divbox/divbox.css\" />\n";
		$my_head .= "<script type=\"text/javascript\" src=\"" . NV_BASE_SITEURL . "js/divbox/divbox.js\"></script>\n";
		$sql = "SELECT * FROM `" . NV_PREFIXLANG . "_video_picture` ORDER BY `pictureid`  DESC LIMIT 0 , 4";
		//$sql1 = "SELECT * FROM `" . NV_PREFIXLANG . "_video` ORDER BY `albumid`";
		if ( ( $result = $db->sql_query( $sql ) ) != false )
		{	
			$xtpl = new XTemplate( "global.videos.tpl", NV_ROOTDIR . "/themes/" . $module_info['template'] . "/modules/video" );
			while ( list( $pictureid, $name, $alias, $path, $description, $numview, $thumb_name, $albumid, $weight, $num_view, $vpath ) = $db->sql_fetchrow( $result ) )
			{	
				$title = nv_clean60 ( strip_tags ( $name ), 70 );
				$xtpl->assign( 'URL', $vpath);
				$xtpl->assign( 'URL_VI', NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=video&amp;" . NV_OP_VARIABLE . "=" . $alias . "/" .$pictureid);
				$xtpl->assign( 'URL_IMG', NV_BASE_SITEURL . NV_UPLOADS_DIR . "/video" . $path );
				$xtpl->assign( 'LINK', NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=video" );
				$xtpl->assign( 'NAME', $title );
				$xtpl->assign( 'NUM', $weight );
				$xtpl->assign( 'NUM_VIEW', $num_view );
				$xtpl->parse( 'main.loop' );
				}   
			$xtpl->parse( 'main' );
			return $xtpl->text( 'main' );
		}
	}
	$content = nv_videos( );
}
?>
