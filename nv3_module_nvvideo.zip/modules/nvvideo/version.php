<?php

/**
 * @Project NUKEVIET 3.4
 * @Author VINADES.,JSC (dlinhvan@gmail.com)
 * @Copyright (C) 2012 Đặng Đình Tứ. All rights reserved
 * @Createdate Mon, 02/07/2012 03:10:00
 */

if( ! defined( 'NV_ADMIN' ) or ! defined( 'NV_MAINFILE' ) )
{
	die( 'Stop!!!' );
}

$module_version = array(
	"name" => "Video", //
	"modfuncs" => "main,viewcat,detail", //
	"is_sysmod" => 0, //
	"virtual" => 1, //
	"version" => "3.1", //
	"date" => "Mon, 02/07/2012 03:10:00 GMT", //
	"author" => "dangdinhtu (dlinhvan@gmail.com)", //
	"note" => "",
	"uploads_dir" => array( $module_name ),
	"files_dir" => array( $module_name ) );

?>