<?php

/**
 * @Project NUKEVIET 3.4
 * @Author VINADES.,JSC (dlinhvan@gmail.com)
 * @Copyright (C) 2012 Đặng Đình Tứ. All rights reserved
 * @Createdate Mon, 02/07/2012 03:10:00
 */

if( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

if( ! nv_function_exists( 'nv_videos_top' ) )
{
	function nv_block_config_videos_top( $module, $data_block, $lang_block )
	{
		global $db, $language_array, $site_mods;
		$mod_data = $site_mods[$module]['module_data'];
		$html = "";
		$html .= "<tr>";
		$html .= "	<td>" . $lang_block['num'] . "</td>";
		$html .= "	<td><input type=\"text\" name=\"config_num\" size=\"5\" value=\"" . $data_block['num'] . "\"/></td>";
		$html .= "<td></tr>";
		return $html;
	}
	function nv_block_config_videos_top_submit( $module, $lang_block )
	{
		global $nv_Request;
		$return = array();
		$return['error'] = array();
		$return['config'] = array();
		$return['config']['num'] = $nv_Request->get_int( 'config_num', 'post', 0 );
		return $return;
	}
	function nv_videos_top( $block_config )
	{
		global $module_info, $site_mods, $db, $global_config, $global_video_cat;
		$module = $block_config['module'];
		$mod_data = $site_mods[$module]['module_data'];
		$mod_file = $site_mods[$module]['module_file'];
		$sql = "SELECT * FROM `" . NV_PREFIXLANG . "_" . $mod_data . "_rows` WHERE status=1 ORDER BY view DESC LIMIT 0," . $block_config['num'];
		$result = $db->sql_query( $sql );

		if( file_exists( NV_ROOTDIR . "/themes/" . $global_config['site_theme'] . "/modules/nvvideo/block_top.tpl" ) )
		{
			$block_theme = $global_config['site_theme'];
		}
		else
		{
			$block_theme = "default";
		}
		$xtpl = new XTemplate( "block_top.tpl", NV_ROOTDIR . "/themes/" . $block_theme . "/modules/nvvideo" );
		$xtpl->assign( 'NV_BASE_SITEURL', NV_BASE_SITEURL );
		$xtpl->assign( 'THEME', $block_theme );
		while( $data = $db->sql_fetchrow( $result, 2 ) )
		{
			$data['link'] = $global_video_cat[$data['catid']]['link'] . "/" . $data['alias'] . "-" . $data['id'];

			$data['addtime'] = nv_date( "l - d/m/Y  H:i", $data['addtime'] );
			$data['hometext'] = nv_clean60( $data['hometext'], 100 );
			if( ! empty( $data['img'] ) )
			{
				$imageinfo = nv_ImageInfo( NV_ROOTDIR . '/' . NV_UPLOADS_DIR . '/' . $module . '/' . $data['img'], 120, true, NV_ROOTDIR . '/' . NV_FILES_DIR . '/' . $module );
				$data['src'] = $imageinfo['src'];
			}
			$xtpl->assign( 'ROW', $data );
			if( ! empty( $data['img'] ) && file_exists( NV_ROOTDIR . '/' . NV_UPLOADS_DIR . '/' . $module . '/' . $data['img'] ) )
			{
				$xtpl->parse( 'main.loop.img' );
			}
			$xtpl->parse( 'main.loop' );
		}
		$xtpl->parse( 'main' );
		return $xtpl->text( 'main' );
	}
}

if( defined( 'NV_SYSTEM' ) )
{
	global $site_mods, $module_name,$global_video_cat;
	$module = $block_config['module'];
    if ( isset( $site_mods[$module] ) )
    {
        if ( $module != $module_name )
        {
            $sql = "SELECT catid, parentid, title, alias, viewcat, subcatid, numlinks, description, inhome, keywords, who_view, groups_view FROM `" . NV_PREFIXLANG . "_" . $site_mods[$module]['module_data'] . "_cat` ORDER BY `order` ASC";
            $list = nv_db_cache( $sql, 'catid', $module );
            foreach ( $list as $l )
            {
                $global_video_cat[$l['catid']] = $l;
                $global_video_cat[$l['catid']]['link'] = NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $module . "&amp;" . NV_OP_VARIABLE . "=" . $l['alias'];
            }
        }
        $content = nv_videos_top( $block_config );
    }
	
}

?>