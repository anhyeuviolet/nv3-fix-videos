<?php

/**
 * @Project NUKEVIET 3.4
 * @Author VINADES.,JSC (dlinhvan@gmail.com)
 * @Copyright (C) 2012 Đặng Đình Tứ. All rights reserved
 * @Createdate Mon, 02/07/2012 03:10:00
 */

if( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

if( ! nv_function_exists( 'nv_videos_new' ) )
{
	function nv_videos_new( $block_config )
	{
		global $module_info, $site_mods, $db, $global_config, $global_video_cat;
		$module = $block_config['module'];
		$mod_data = $site_mods[$module]['module_data'];
		$mod_file = $site_mods[$module]['module_file'];
		$sql = "SELECT * FROM `" . NV_PREFIXLANG . "_" . $mod_data . "_rows` WHERE status=1 AND img!= '' ORDER BY id DESC LIMIT 1";
		$result = $db->sql_query( $sql );

		if( file_exists( NV_ROOTDIR . "/themes/" . $global_config['site_theme'] . "/modules/nvvideo/block_new.tpl" ) )
		{
			$block_theme = $global_config['site_theme'];
		}
		else
		{
			$block_theme = "default";
		}
		$xtpl = new XTemplate( "block_new.tpl", NV_ROOTDIR . "/themes/" . $block_theme . "/modules/nvvideo" );
		if( file_exists( NV_ROOTDIR . '/modules/' . $mod_file . '/language/' . NV_LANG_DATA . '.php' ) )
		{
			require_once ( NV_ROOTDIR . '/modules/' . $mod_file . '/language/' . NV_LANG_DATA . '.php' );
		}

		$xtpl->assign( 'NV_BASE_SITEURL', NV_BASE_SITEURL );
		$xtpl->assign( 'THEME', $block_theme );
		while( $data = $db->sql_fetchrow( $result, 2 ) )
		{
			$data['link'] = $global_video_cat[$data['catid']]['link'] . "/" . $data['alias'] . "-" . $data['id'];
			$data['hometext'] = nv_clean60( $data['hometext'], 160 );
			$data['title1'] = nv_clean60( $data['title'], 60 );
			if( ! empty( $data['img'] ) )
			{
				$data['src'] = NV_BASE_SITEURL . "" . NV_UPLOADS_DIR . "/" . $module . "/" . $data['img'];
			}
			$xtpl->assign( 'ROW', $data );
			$xtpl->parse( 'main.loop' );
		}
		$xtpl->parse( 'main' );
		return $xtpl->text( 'main' );
	}
}

if( defined( 'NV_SYSTEM' ) )
{
	global $site_mods, $module_name, $global_video_cat;
	$module = $block_config['module'];
	if( isset( $site_mods[$module] ) )
	{
		if( $module == $module_name )
		{

			unset( $global_video_cat[0] );
		}
		else
		{
			$global_video_cat = array();
			$sql = "SELECT catid, parentid, title, alias, viewcat, subcatid, numlinks, description, inhome, keywords, who_view, groups_view FROM `" . NV_PREFIXLANG . "_" . $site_mods[$module]['module_data'] .
				"_cat` ORDER BY `order` ASC";
			$list = nv_db_cache( $sql, 'catid', $module );
			foreach( $list as $l )
			{
				$global_video_cat[$l['catid']] = $l;
				$global_video_cat[$l['catid']]['link'] = NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $module . "&amp;" . NV_OP_VARIABLE . "=" . $l['alias'];
			}
		}
		$content = nv_videos_new( $block_config );
	}

}

?>