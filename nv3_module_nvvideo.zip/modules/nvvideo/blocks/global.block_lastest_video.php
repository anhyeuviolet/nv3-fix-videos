<?php

/**
 * @Project NUKEVIET 3.4
 * @Author Nguyen Thanh Chung (chung_vuitinh@yahoo.com)
 * @Createdate 8-1-2012 9:00
 */
if (! defined ( 'NV_MAINFILE' )) {
	die ( 'Stop!!!' );
}

if (! nv_function_exists ( 'nv_video_blocks' )) {
	
	function nv_video_blocks ($mod_theme,$mod_data) 
	{
	   global $db;
		if ( file_exists( NV_ROOTDIR . "/themes/" . $mod_theme . "/modules/".$mod_data."/block_lastest_video.tpl" ) )
            {
                $block_theme = $mod_theme;
            }
        else
            {
                $block_theme = "default";                
            }
        
            $xtpl = new XTemplate( "block_lastest_video.tpl", NV_ROOTDIR . "/themes/" . $block_theme . "/modules/".$mod_data."" );
        
        $query = "SELECT id, catid, title, alias, img, filepath, otherpath, hometext FROM `" . NV_PREFIXLANG . "_".$mod_data."_rows` WHERE status=1 AND img!= '' ORDER BY id DESC LIMIT 0,3";
        $result = $db->sql_query ( $query );
		$i=0;
        while ($row = $db->sql_fetchrow ( $result ))
        {
			$i++;
			if($i==1)
			{
                if(!empty($row['filepath'])){
                    $video = NV_BASE_SITEURL . NV_UPLOADS_DIR . "/".$mod_data."/".$row['filepath'];
				}
                else
                {
                    $video = $row['otherpath'];
                }
                $img =  NV_BASE_SITEURL . NV_UPLOADS_DIR . "/".$mod_data."/". $row['img'];		
				$xtpl->assign ( 'VTITLE', $row['title'] );
				$xtpl->assign ( 'IMG', $img );
				$xtpl->assign ( 'VIDEO', $video );	
				$xtpl->assign ( 'NV_BASE_SITEURL', NV_BASE_SITEURL );
			}
			else 
			{
				$sql = "SELECT alias FROM `" . NV_PREFIXLANG . "_".$mod_data."_cat` where `catid` = ".$row['catid'];
				$result1 = $db->sql_query ( $sql);
				list( $alias_cat ) = $db ->sql_fetchrow($result1);
                
				$row['link'] = NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=".$mod_data."&amp;" . NV_OP_VARIABLE . "=".$alias_cat."/".$row['alias']."-".$row['id'];
                $xtpl->assign ( 'DATA', $row );
				$xtpl->parse ( 'main.loop' );
			}
        }
		$xtpl->parse ( 'main' );
		return $xtpl->text ( 'main' );
	
    }
}

if ( defined( 'NV_SYSTEM' ) )
{
    global $site_mods,$module_info;
    $mod_data=$site_mods[$block_config['module']]['module_data'];
    $mod_theme=$module_info['template'];
	$content = nv_video_blocks($mod_theme,$mod_data);
}

?>