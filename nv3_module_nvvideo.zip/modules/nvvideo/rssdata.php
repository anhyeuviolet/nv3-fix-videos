<?php

/**
 * @Project NUKEVIET 3.4
 * @Author VINADES.,JSC (dlinhvan@gmail.com)
 * @Copyright (C) 2012 Đặng Đình Tứ. All rights reserved
 * @Createdate Mon, 02/07/2012 03:10:00
 */

if( ! defined( 'NV_IS_MOD_RSS' ) ) die( 'Stop!!!' );

$rssarray = array();
$sql = "SELECT `catid`, `parentid`, `title`, `alias` FROM `" . NV_PREFIXLANG . "_" . $mod_data . "_cat` ORDER BY `weight`, `order`";
//$rssarray[] = array( 'catid' => 0, 'parentid' => 0, 'title' => '', 'link' =>  '');

$list = nv_db_cache( $sql, '', $mod_name );
foreach( $list as $value )
{
	$value['link'] = NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $mod_name . "&amp;" . NV_OP_VARIABLE . "=rss/" . $value['alias'];
	$rssarray[] = $value;
}

?>