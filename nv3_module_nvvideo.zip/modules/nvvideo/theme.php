<?php

/**
 * @Project NUKEVIET 3.4
 * @Author VINADES.,JSC (dlinhvan@gmail.com)
 * @Copyright (C) 2012 Đặng Đình Tứ. All rights reserved
 * @Createdate Mon, 02/07/2012 03:10:00
 */

if( ! defined( 'NV_IS_MOD_VIDEO' ) ) die( 'Stop!!!' );

function nv_viewcatpage( $data_content, $generate_page )
{
	global $global_config, $module_name, $module_file, $lang_module, $module_config, $module_info, $global_video_cat;
	$xtpl = new XTemplate( "main.tpl", NV_ROOTDIR . "/themes/" . $module_info['template'] . "/modules/" . $module_file );
	$xtpl->assign( 'LANG', $lang_module );
	$xtpl->assign( 'NV_BASE_SITEURL', NV_BASE_SITEURL );
	$xtpl->assign( 'TEMPLATE', $module_info['template'] );
	if( ! empty( $data_content ) )
	{
		foreach( $data_content as $data_content_i )
		{
			if( ! empty( $data_content_i['data'] ) )
			{
				$xtpl->assign( 'CATE', $data_content_i['catinfo'] );
				if( $data_content_i['catinfo']['numsubcat'] > 0 )
				{
					$arraysub = explode( ",", $data_content_i['catinfo']['subcatid'] );
					foreach( $arraysub as $sub )
					{
						$xtpl->assign( 'SUB', $global_video_cat[$sub] );
						$xtpl->parse( 'main.cat.subcat' );
					}
				}
				foreach( $data_content_i['data'] as $row )
				{

					$row['addtime'] = date( "d/m/Y", $row['addtime'] );
					if( ! empty( $row['img'] ) )
					{
						$imageinfo = nv_ImageInfo( NV_ROOTDIR . '/' . NV_UPLOADS_DIR . '/' . $module_name . '/' . $row['img'], 120, true, NV_ROOTDIR . '/' . NV_FILES_DIR . '/' . $module_name );
						$row['img'] = $imageinfo['src'];
					}
					$row['title1'] = nv_clean60( $row['title'], 20 );
					$xtpl->assign( 'ROW', $row );
					if( ! empty( $row['img'] ) ) $xtpl->parse( 'main.cat.loop.img' );
					$xtpl->parse( 'main.cat.loop' );
				}
				$xtpl->parse( 'main.cat' );
			}
		}
		if( ! empty( $generate_page ) )
		{
			$xtpl->assign( 'GENERATE_PAGE', $generate_page );
			$xtpl->parse( 'main.generate_page' );
		}
	}
	$xtpl->parse( 'main' );
	return $xtpl->text( 'main' );
}

function nv_viewcatall( $data_content, $generate_page )
{
	global $global_config, $module_name, $module_file, $lang_module, $module_config, $module_info;
	$xtpl = new XTemplate( "main_listall.tpl", NV_ROOTDIR . "/themes/" . $module_info['template'] . "/modules/" . $module_file );
	$xtpl->assign( 'LANG', $lang_module );
	$xtpl->assign( 'NV_BASE_SITEURL', NV_BASE_SITEURL );
	$xtpl->assign( 'TEMPLATE', $module_info['template'] );
	if( ! empty( $data_content ) )
	{
		foreach( $data_content as $row )
		{
			$row['addtime'] = date( "d/m/Y", $row['addtime'] );
			if( ! empty( $row['img'] ) )
			{
				$imageinfo = nv_ImageInfo( NV_ROOTDIR . '/' . NV_UPLOADS_DIR . '/' . $module_name . '/' . $row['img'], 120, true, NV_ROOTDIR . '/' . NV_FILES_DIR . '/' . $module_name );
				$row['img'] = $imageinfo['src'];
			}
			$row['title1'] = nv_clean60( $row['title'], 20 );
			$xtpl->assign( 'ROW', $row );
			if( ! empty( $row['img'] ) ) $xtpl->parse( 'main.loop.img' );
			$xtpl->parse( 'main.loop' );
		}
	}
	if( ! empty( $generate_page ) )
	{
		$xtpl->assign( 'GENERATE_PAGE', $generate_page );
		$xtpl->parse( 'main.generate_page' );
	}
	$xtpl->parse( 'main' );
	return $xtpl->text( 'main' );
}
function nv_new_hit( $data_content, $generate_page )
{
	global $global_config, $module_name, $module_file, $lang_module, $module_config, $module_info;
	$xtpl = new XTemplate( "new_head.tpl", NV_ROOTDIR . "/themes/" . $module_info['template'] . "/modules/" . $module_file );
	$xtpl->assign( 'LANG', $lang_module );
	$xtpl->assign( 'NV_BASE_SITEURL', NV_BASE_SITEURL );
	$xtpl->assign( 'TEMPLATE', $module_info['template'] );
	if( ! empty( $data_content ) )
	{
		$stt = 0;
		foreach( $data_content as $row )
		{
			$row['addtime'] = date( "d/m/Y", $row['addtime'] );
			if( ! empty( $row['img'] ) )
			{
				$imageinfo = nv_ImageInfo( NV_ROOTDIR . '/' . NV_UPLOADS_DIR . '/' . $module_name . '/' . $row['img'], 120, true, NV_ROOTDIR . '/' . NV_FILES_DIR . '/' . $module_name );
				$row['img'] = $imageinfo['src'];
			}
			$row['title1'] = nv_clean60( $row['title'], 20 );
			$xtpl->assign( 'ROW', $row );
			if( ! empty( $row['img'] ) ) $xtpl->parse( 'main.loop.img' );
			++$stt;
			if( $stt % 4 == 0 )
			{
				$xtpl->parse( 'main.loop.clear' );
			}
			$xtpl->parse( 'main.loop' );
		}
	}
	if( ! empty( $generate_page ) )
	{
		$xtpl->assign( 'GENERATE_PAGE', $generate_page );
		$xtpl->parse( 'main.generate_page' );
	}
	$xtpl->parse( 'main' );
	return $xtpl->text( 'main' );
}
function nv_load_video( $data_content, $pages )
{
	global $db, $global_config, $config, $module_name, $module_file, $lang_module, $module_config, $module_info, $my_head;
	$xtpl = new XTemplate( "load.tpl", NV_ROOTDIR . "/themes/" . $module_info['template'] . "/modules/" . $module_file );
	$xtpl->assign( 'LANG', $lang_module );
	$xtpl->assign( 'NV_BASE_SITEURL', NV_BASE_SITEURL );
	$stt = 0;
	foreach( $data_content as $row )
	{
		$row['addtime'] = date( "d/m/Y", $row['addtime'] );
		if( ! empty( $row['img'] ) )
		{
			$imageinfo = nv_ImageInfo( NV_ROOTDIR . '/' . NV_UPLOADS_DIR . '/' . $module_name . '/' . $row['img'], 120, true, NV_ROOTDIR . '/' . NV_FILES_DIR . '/' . $module_name );
			$row['img'] = $imageinfo['src'];
		}
		$row['title1'] = nv_clean60( $row['title'], 20 );
		$xtpl->assign( 'ROW', $row );
		if( ! empty( $row['img'] ) ) $xtpl->parse( 'main.loop.img' );
		++$stt;
		if( $stt % 4 == 0 )
		{
			$xtpl->parse( 'main.loop.clear' );
		}
		$xtpl->parse( 'main.loop' );

	}
	if( ! empty( $pages ) )
	{
		$xtpl->assign( 'pages', $pages );
	}
	$xtpl->parse( 'main.pages' );
	$xtpl->parse( 'main' );
	return $xtpl->text( 'main' );
}

function nv_video_detail( $data_content, $data_other = array() )
{
	global $global_config, $module_name, $module_file, $lang_module, $module_config, $module_info;
	$xtpl = new XTemplate( "detail.tpl", NV_ROOTDIR . "/themes/" . $module_info['template'] . "/modules/" . $module_file );
	$xtpl->assign( 'LANG', $lang_module );
	$xtpl->assign( 'NV_BASE_SITEURL', NV_BASE_SITEURL );
	$xtpl->assign( 'TEMPLATE', $module_info['template'] );
	$xtpl->assign( 'DATA', $data_content );
	if( ! empty( $data_content['otherpath'] ) ) $xtpl->parse( 'main.linko' );
	if( ! empty( $data_content['file_src'] ) ) $xtpl->parse( 'main.file' );
	if( ! empty( $data_content['embed'] ) ) $xtpl->parse( 'main.embed' );
	if( ! empty( $data_other ) )
	{
		foreach( $data_other as $row )
		{
			$row['addtime'] = date( "d/m/Y", $row['addtime'] );
			if( ! empty( $row['img'] ) ) $row['img'] = NV_BASE_SITEURL . "" . NV_UPLOADS_DIR . "/" . $module_name . "/" . $row['img'];
			$row['title1'] = nv_clean60( $row['title'], 20 );
			$xtpl->assign( 'ROW', $row );
			if( ! empty( $row['img'] ) ) $xtpl->parse( 'main.loop.img' );
			$xtpl->parse( 'main.loop' );
		}
	}
	$xtpl->parse( 'main' );
	return $xtpl->text( 'main' );
}

function viewcat_list( $data_content, $top_contents = "", $generate_page )
{
	return nv_viewcatall( $data_content, $generate_page );
}

function viewcat_gird( $data_content, $top_contents = "", $generate_page )
{
	return nv_viewcatall( $data_content, $generate_page );
}

?>