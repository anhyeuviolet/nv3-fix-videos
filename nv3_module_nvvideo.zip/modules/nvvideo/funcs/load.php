<?php

/**
 * @Project NUKEVIET 3.0
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2010 VINADES., JSC. All rights reserved
 * @Createdate 3-31-2010 0:33
 */

if( ! defined( 'NV_IS_MOD_VIDEO' ) ) die( 'Stop!!!' );
$page_title = $module_info['custom_title'];
$key_words = $module_info['keywords'];
$page = $nv_Request->get_int( 'page', 'get,post', 0 );
$base_url = NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&" . NV_NAME_VARIABLE . "=" . $module_name . "&amp;" . NV_OP_VARIABLE . "=load";
$sql = "SELECT SQL_CALC_FOUND_ROWS * FROM `" . NV_PREFIXLANG . "_" . $module_data . "_rows` WHERE status=1 ORDER BY view DESC LIMIT " . $page . "," . $per_page;
$result = $db->sql_query( $sql );
$result_all = $db->sql_query( "SELECT FOUND_ROWS()" );
list( $numf ) = $db->sql_fetchrow( $result_all );
$all_page = ( $numf ) ? $numf : 1;
while( $row = $db->sql_fetchrow( $result ) )
{
	$row['link'] = $global_video_cat[$row['catid']]['link'] . "/" . $row['alias'] . "-" . $row['id'];
	$content_array[] = $row;
}
$db->sql_freeresult( $result );
$pages = nv_generate_page( $base_url, $all_page, $per_page, $page, true, true, 'nv_urldecode_ajax', 'load' );
if( ! empty( $content_array ) )
{
	$contents = nv_load_video( $content_array, $pages );
}
else
{
	$contents = $lang_module['nocatpage'];
}

include ( NV_ROOTDIR . "/includes/header.php" );
echo $contents;
include ( NV_ROOTDIR . "/includes/footer.php" );

?>