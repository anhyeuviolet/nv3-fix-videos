<?php

/**
 * @Project NUKEVIET 3.4
 * @Author VINADES.,JSC (dlinhvan@gmail.com)
 * @Copyright (C) 2012 Đặng Đình Tứ. All rights reserved
 * @Createdate Mon, 02/07/2012 03:10:00
 */

if( ! defined( 'NV_IS_MOD_VIDEO' ) )
{
	die( 'Stop!!!' );
}

$page_title = $module_info['custom_title'];
$key_words = $module_info['keywords'];

$base_url = "" . NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&" . NV_NAME_VARIABLE . "=" . $module_name . "&" . NV_OP_VARIABLE . "=" . $op;
$table = "`" . NV_PREFIXLANG . "_" . $module_data . "_rows`";

if( $data_config['view_type'] == "nv_viewcatall" )
{
	$sql = "SELECT SQL_CALC_FOUND_ROWS * FROM " . $table . " WHERE status=1 ORDER BY id DESC LIMIT " . ( $page - 1 ) * $per_page . "," . $per_page;
	$result = $db->sql_query( $sql );
	$result_all = $db->sql_query( "SELECT FOUND_ROWS()" );
	list( $numf ) = $db->sql_fetchrow( $result_all );
	$all_page = ( $numf ) ? $numf : 1;
	$data_content = array();
	$i = $page + 1;
	while( $row = $db->sql_fetchrow( $result, 2 ) )
	{
		$row['no'] = $i;
		$row['link'] = $global_video_cat[$row['catid']]['link'] . "/" . $row['alias'] . "-" . $row['id'];

		$data_content[] = $row;
		$i++;
	}
	$generate_page = nv_alias_page( $page_title, $base_url, $all_page, $per_page, $page );
	$contents = call_user_func( $data_config['view_type'], $data_content, $generate_page );
}
elseif( $data_config['view_type'] == "nv_viewcatpage" )
{
	$data_content = array();
	foreach( $global_video_cat as $catid_i => $catinfo_i )
	{
		if( $catinfo_i['parentid'] == 0 and $catinfo_i['inhome'] == '1' )
		{
			$sql = "SELECT SQL_CALC_FOUND_ROWS * FROM " . $table . " WHERE catid=" . $catid_i . " AND status=1 ORDER BY id DESC LIMIT 0," . $catinfo_i['numlinks'];
			$result = $db->sql_query( $sql );
			$result_all = $db->sql_query( "SELECT FOUND_ROWS()" );
			list( $numf ) = $db->sql_fetchrow( $result_all );
			$all_page = ( $numf ) ? $numf : 1;
			$data_content_temp = array();
			$i = $page + 1;
			while( $row = $db->sql_fetchrow( $result, 2 ) )
			{
				$row['no'] = $i;
				$row['link'] = $global_video_cat[$catid_i]['link'] . "/" . $row['alias'] . "-" . $row['id'];
				$data_content_temp[] = $row;
				$i++;
			}
			$data_content[] = array( "catinfo" => $catinfo_i, "data" => $data_content_temp );
		}
	}
	$contents = call_user_func( $data_config['view_type'], $data_content, "" );
}
elseif( $data_config['view_type'] == "nv_new_hit" )
{
	$my_head .= "<script type=\"text/javascript\" src=\"" . NV_BASE_SITEURL . "js/ui/jquery.ui.core.min.js\"></script>\n";
	$my_head .= "<script type=\"text/javascript\" src=\"" . NV_BASE_SITEURL . "js/ui/jquery.ui.tabs.min.js\"></script>\n";
	$my_head .= "	<script type=\"text/javascript\">\n";
	$my_head .= "	$(function() {\n";
	$my_head .= "	$(\"#tabs_top\").tabs({cache: true});\n";
	$my_head .= "	});\n";
	$my_head .= "	</script>\n";
	$sql = "SELECT SQL_CALC_FOUND_ROWS * FROM " . $table . " WHERE status=1 ORDER BY addtime DESC LIMIT " . ( $page - 1 ) * $per_page . "," . $per_page;
	$result = $db->sql_query( $sql );
	$result_all = $db->sql_query( "SELECT FOUND_ROWS()" );
	list( $numf ) = $db->sql_fetchrow( $result_all );
	$all_page = ( $numf ) ? $numf : 1;
	$data_content = array();
	$i = $page + 1;
	while( $row = $db->sql_fetchrow( $result, 2 ) )
	{
		$row['no'] = $i;
		$row['link'] = $global_video_cat[$row['catid']]['link'] . "/" . $row['alias'] . "-" . $row['id'];

		$data_content[] = $row;
		$i++;
	}
	$generate_page = nv_alias_page( $page_title, $base_url, $all_page, $per_page, $page );
	$contents = call_user_func( $data_config['view_type'], $data_content, $generate_page );
}
else  $contents = "";

include ( NV_ROOTDIR . "/includes/header.php" );
echo nv_site_theme( $contents );
include ( NV_ROOTDIR . "/includes/footer.php" );

?>