<?php

/**
 * @Project NUKEVIET 3.4
 * @Author VINADES.,JSC (dlinhvan@gmail.com)
 * @Copyright (C) 2012 Đặng Đình Tứ. All rights reserved
 * @Createdate Mon, 02/07/2012 03:10:00
 */

if( ! defined( 'NV_IS_MOD_VIDEO' ) ) die( 'Stop!!!' );

$page_title = $module_info['custom_title'];
$key_words = $module_info['keywords'];

$base_url = $global_video_cat[$catid]['link'];
$table = "`" . NV_PREFIXLANG . "_" . $module_data . "_rows`";

$sql = "SELECT SQL_CALC_FOUND_ROWS * FROM " . $table . " WHERE catid=" . $catid . " AND status=1 ORDER BY id DESC LIMIT " . ( $page - 1 ) * $per_page . "," . $per_page;
$result = $db->sql_query( $sql );
$result_all = $db->sql_query( "SELECT FOUND_ROWS()" );
list( $numf ) = $db->sql_fetchrow( $result_all );
$all_page = ( $numf ) ? $numf : 1;
$data_content = array();
$i = $page + 1;
while( $row = $db->sql_fetchrow( $result, 2 ) )
{
	$row['no'] = $i;
	$row['link'] = $global_video_cat[$row['catid']]['link'] . "/" . $row['alias'] . "-" . $row['id'];
	$data_content[] = $row;
	$i++;
}
$top_contents = "";
if( $global_video_cat[$catid]['parentid'] > 0 )
{
	$parentid_i = $global_video_cat[$catid]['parentid'];
	$array_cat_title = array();
	while( $parentid_i > 0 )
	{
		$array_cat_title[] = $cur_link = "<a href=\"" . $global_video_cat[$parentid_i]['link'] . "\">" . $global_video_cat[$parentid_i]['title'] . "</a>";
		$parentid_i = $global_video_cat[$parentid_i]['parentid'];
	}
	sort( $array_cat_title, SORT_NUMERIC );
	$top_contents = implode( " -> ", $array_cat_title );
}
$lik = ( empty( $top_contents ) ) ? "" : " - ";
$cur_link = "<a href=\"" . $global_video_cat[$catid]['link'] . "\">" . $global_video_cat[$catid]['title'] . "</a>";
$top_contents = "<div class=\"archives_links\">" . $top_contents . $lik . $cur_link . "</div>";

$generate_page = nv_alias_page( $page_title, $base_url, $all_page, $per_page, $page );
$contents = call_user_func( $global_video_cat[$catid]['viewcat'], $data_content, $top_contents, $generate_page );

include ( NV_ROOTDIR . "/includes/header.php" );
echo nv_site_theme( $contents );
include ( NV_ROOTDIR . "/includes/footer.php" );

?>