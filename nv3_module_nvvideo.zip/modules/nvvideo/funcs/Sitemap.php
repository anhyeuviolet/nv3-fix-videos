<?php

/**
 * @Project NUKEVIET 3.4
 * @Author VINADES.,JSC (dlinhvan@gmail.com)
 * @Copyright (C) 2012 Đặng Đình Tứ. All rights reserved
 * @Createdate Mon, 02/07/2012 03:10:00
 */

if( ! defined( 'NV_IS_MOD_VIDEO' ) ) die( 'Stop!!!' );

$url = array();
$cacheFile = NV_ROOTDIR . "/" . NV_CACHEDIR . "/" . NV_LANG_DATA . "_" . $module_data . "_Sitemap.cache";
$pa = NV_CURRENTTIME - 7200;

if( ( $cache = nv_get_cache( $cacheFile ) ) != false and filemtime( $cacheFile ) >= $pa )
{
	$url = unserialize( $cache );
}
else
{
	$sql = "SELECT `id`, `catid`, `addtime`, `alias` FROM `" . NV_PREFIXLANG . "_" . $module_data . "_rows` WHERE `status`=1 ORDER BY `addtime` DESC LIMIT 1000";
	$result = $db->sql_query( $sql );
	$url = array();

	while( list( $id, $catid_i, $addtime, $alias ) = $db->sql_fetchrow( $result ) )
	{
		$catalias = $global_video_cat[$catid_i]['alias'];
		$url[] = array( //
				'link' => NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $module_name . "&amp;" . NV_OP_VARIABLE . "=" . $catalias . '/' . $alias . '-' .
				$id, //
				'publtime' => $addtime //
				);
	}

	$cache = serialize( $url );
	nv_set_cache( $cacheFile, $cache );
}

nv_xmlSitemap_generate( $url );
die();

?>