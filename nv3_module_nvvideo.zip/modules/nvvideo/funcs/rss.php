<?php

/**
 * @Project NUKEVIET 3.4
 * @Author VINADES.,JSC (dlinhvan@gmail.com)
 * @Copyright (C) 2012 Đặng Đình Tứ. All rights reserved
 * @Createdate Mon, 02/07/2012 03:10:00
 */

if( ! defined( 'NV_IS_MOD_VIDEO' ) ) die( 'Stop!!!' );



$channel = array();
$items = array();

$channel['title'] = $module_info['custom_title'];
$channel['link'] = NV_MY_DOMAIN . NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $module_name;
$channel['description'] = ! empty( $module_info['description'] ) ? $module_info['description'] : $global_config['site_description'];

$catid = 0;
if( isset( $array_op[1] ) )
{
	$alias_cat_url = $array_op[1];
	$cattitle = "";
	foreach( $global_video_cat as $catid_i => $array_cat_i )
	{
		if( $alias_cat_url == $array_cat_i['alias'] )
		{
			$catid = $catid_i;
			break;
		}
	}
}

if( ! empty( $catid ) )
{
	$channel['title'] = $module_info['custom_title'] . ' - ' . $global_video_cat[$catid]['title'];
	$channel['link'] = NV_MY_DOMAIN . NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $module_name . "&amp;" . NV_OP_VARIABLE . "=" . $alias_cat_url;
	$channel['description'] = $global_video_cat[$catid]['description'];

	$sql = "SELECT id, catid, addtime, title, alias, hometext, img FROM `" . NV_PREFIXLANG . "_" . $module_data . "_" . $catid . "` WHERE `status`=1 ORDER BY `addtime` DESC LIMIT 30";
}
else
{
	$sql = "SELECT id, catid, addtime, title, alias, hometext, img FROM `" . NV_PREFIXLANG . "_" . $module_data . "_rows` WHERE `status`=1  ORDER BY `addtime` DESC LIMIT 30";
}

if( $module_info['rss'] )
{
	$result = $db->sql_query( $sql );
	while( list( $id, $catid_i, $addtime, $title, $alias, $hometext, $img ) = $db->sql_fetchrow( $result ) )
	{
		if( ! empty( $catid ) ) $catid_i = $catid;
		$catalias = $global_video_cat[$catid_i]['alias'];

		if( nv_is_url( $img ) )
		{
			$rimages = $img;
		}
		elseif( $img != "" and file_exists( NV_UPLOADS_REAL_DIR . '/' . $module_name . '/' . $img ) )
		{
			$rimages = NV_MY_DOMAIN . NV_BASE_SITEURL . NV_UPLOADS_DIR . '/' . $module_name . '/' . $img;
		}
		else
		{
			$rimages = "";
		}
		$rimages = ( ! empty( $rimages ) ) ? "<img src=\"" . $rimages . "\" width=\"100\" align=\"left\" border=\"0\">" : "";

		$items[] = array( //
			'title' => $title, //
			'link' => NV_MY_DOMAIN . NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $module_name . "&amp;" . NV_OP_VARIABLE . "=" . $catalias . '/' .
				$alias . '-' . $id, //
			'guid' => $module_name . '_' . $id, //
			'description' => $rimages . $hometext, //
			//'pubdate' => $addtime //
			);
			
	}
	
}
//var_dump($items);
nv_rss_generate( $channel, $items );
die();

?>