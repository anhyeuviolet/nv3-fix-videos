<?php

/**
 * @Project NUKEVIET 3.4
 * @Author VINADES.,JSC (dlinhvan@gmail.com)
 * @Copyright (C) 2012 Đặng Đình Tứ. All rights reserved
 * @Createdate Mon, 02/07/2012 03:10:00
 */

if( ! defined( 'NV_MAINFILE' ) )
{
	die( 'Stop!!!' );
}

$lang_translator['author'] = "Đặng Đình Tứ (dlinhvan@gmail.com)";
$lang_translator['createdate'] = "02/07/2012 03:10";
$lang_translator['copyright'] = "@Copyright (C) 2012 Đặng Đình Tứ. All rights reserved";
$lang_translator['info'] = "";
$lang_translator['langtype'] = "lang_module";

$lang_module['view'] = "Lượt xem";
$lang_module['otherfile'] = "Các videos khác";
$lang_module['otherlink'] = "Nếu không xem được bạn hãy click vào link";
$lang_module['nocatpage'] = "không có video nào";

?>